# -*- coding: utf-8 -*-

import cookielib, urllib, urllib2, re, sys

class VkontakteNotLoggedInError(Exception):
    pass

class VkontakteAuth:
    def __init__(self):
        self._vkontakte_cookie = cookielib.CookieJar()
        self._logged_in = False
        self._vkontakte_id = -1
        
    def get_cookie(self):
        if not self.IsLoggedIn():
            raise VkontakteNotLoggedInError()
        return self._vkontakte_cookie;

    def _get_s_value(self, login, password):
        # Короче, теперь авторизация идет по-жесткой
        # Идем на спецстраницу с логином и паролем
        # Если что-то не так, то нам 403 пихают
        # Если все норм, то дают какой-то код 's'

        host = 'http://login.vk.com/?act=login'
        post = urllib.urlencode({'email': login,
                                'expire': '',
                                'pass': password,
                                'vk': ''})

        try:
            conn = urllib2.Request(host, post)
            data = self._opener.open(conn).read()
        except urllib2.HTTPError, e:
            if e.code == 403:
                print >> sys.stderr, u'Unexpected response status: wrong password?'
            else:
                print >> sys.stderr, u'URLError happen %s' % e
            return ''

        return re.findall(r"name='s' id='s' value='(.*?)'", data)[0]
    
    def IsLoggedIn(self):
        return self._logged_in
    
    def GetID(self):
        return self._vkontakte_id
    
    def Login(self, login, password):
        print >> sys.stderr, u"Logging in..."
        self._logged_in = False
        self._opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self._vkontakte_cookie))

        # С тем параметром 's', что нам дали, надо получить куки
        print >> sys.stderr, u"s-value,"
        auth_data = {'s': self._get_s_value(login, password)}
        try:
            print >> sys.stderr, u"cookies,"
            self._opener.open("http://vkontakte.ru/login.php?op=slogin", urllib.urlencode(auth_data))
            # Все, здесь куки уже в кукиджаре

            # Теперь получать айди приходится загружая весь профиль :( Вот хрень. Редиректа нет.
            print >> sys.stderr, u"profile,"
            response = self._opener.open('http://vkontakte.ru');                    

            match = re.search(r'vkontakte\.ru/id(\d+)', response.geturl())
            if match:
                self._logged_in = True
                self._vkontakte_id = int(match.group(1))
                print >> sys.stderr, u"done (%s)." % self._vkontakte_id
            else:
                print >> sys.stderr, u'Unexpected response URL: wrong password?'
                
        except urllib2.URLError, e:
            print >> sys.stderr, u'URLError happen %s' % e
            pass

        return self._logged_in
    